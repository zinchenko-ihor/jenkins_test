# project_template
Typical repo for new devops project

./ansible - ansible roles for mahaging the project
./openshift - templates for openshift objects